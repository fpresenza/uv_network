=======================
Un paquete herramientas
=======================

El paquete contiene herramientas en desarrollo de redes reconfigurables
de vehiculos no tripulados.

Instalación
===========

Con lo siguiente se puede ejecutar `import uvnpy` desde cualquier
lado y funcionaría.

Ejecutar:

.. code-block:: bash

   python3 setup.py sdist bdist_wheel
   pip3 install ./dist/uvnpy-0.0.1.tar.gz


