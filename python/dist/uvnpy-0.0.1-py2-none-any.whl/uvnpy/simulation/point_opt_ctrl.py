#!/usr/bin/env python
# -*- coding: utf-8 -*-
""" Created on Thu Ago 5 11:00:29 2020
@author: fran
"""
import argparse
import numpy as np
from uvnpy.vehicles.point import Point
import uvnpy.graphix.planar as planar

def run(arg, r, landmarks):    
    # times and frequencies
    time = np.arange(arg.ti+arg.h, arg.tf, arg.h)
    cmd_v = (0., 0.)

    # logs
    x = []

    for t in time:
        # r.motion.step(cmd_v, t)
        # x.append(r.motion.x.copy())
            # if not k%(arg.h**-1):
            #     # update cmd vel every 1 second
            #     cmd_v = np.random.normal(0, [1,1])

        r.motion.step(cmd_v, t)
        r.ctrl_step(cmd_v, t, landmarks=landmarks)
        x.append(r.motion.x.copy())
        r.filter.save()

    return time, x, r.filter.log


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-s', '--step', dest='h', default=50e-3, type=float, help='paso de simulación')
    parser.add_argument('-t', '--ti', metavar='T0', default=0.0, type=float, help='tiempo inicial')
    parser.add_argument('-e', '--tf', default=1.0, type=float, help='tiempo final')
    parser.add_argument('-g', '--save', default=False, action='store_true', help='flag para guardar los videos')
    parser.add_argument('-a', '--animate', default=False, action='store_true', help='flag para generar animaicion 3D')

    arg = parser.parse_args()

    # landmarks
    landmarks = [(0,-10), (0,10)]
    # landmarks = []

    r = Point(1, motion_kw={'pi':np.zeros(2), 'freq':arg.h**(-1)})

    t, x, f = run(arg, r, landmarks)

    state_plot = planar.GridPlot(shape=(2,1), xlabel='t [m]')
    x = np.vstack(x).T
    xf = np.vstack(f.x).T
    c = ('r','g'),('r','g')
    s = ('dotted','dotted'), ('dotted','dotted')
    l = ('$p_x$', '$p_y$'), ('$v_x$', '$v_y$') 
    state_plot.draw(t, (x[:2], x[2:]), color=c, label=l)
    state_plot.draw(t, (xf[:2], xf[2:]), color=c, ls=s)
    state_plot.fig.tight_layout()

    covar_plot = planar.GridPlot(shape=(2,1), xlabel='t [m]')
    dxf = np.vstack(f.dx).T
    c = ('r','g'),('r','g')
    l = ('$\sigma(p_x)$', '$\sigma(p_y)$'), ('$\sigma(v_x)$', '$\sigma(v_y)$')
    covar_plot.draw(t, (dxf[:2], dxf[2:]), color=c, label=l)

    if arg.save:
        state_plot.savefig('state_plot')
    else:
        state_plot.show()

    P = {'1': x[:2].T}
    L = [[] for _ in t]
    graph_plotter = planar.GraphPlotter(t, P, L, save=arg.save, landmarks=landmarks)
    if arg.animate:
        graph_plotter.animation2d(step=2, plot_kw={'xlim':[-40,40], 'ylim':[-40,40]})