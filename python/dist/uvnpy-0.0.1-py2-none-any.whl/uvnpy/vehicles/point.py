#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 06 12:41:07 2020
@author: fran
"""
import numpy as np
import collections
import yaml
import uvnpy.toolkit.linalg as linalg
from uvnpy.vehicles.unmanned_vehicle import UnmannedVehicle
from uvnpy.model.holonomic import VelocityModel, VelocityRandomWalk
from uvnpy.navigation.kalman import Ekf
from uvnpy.sensor.imu import Imu
from uvnpy.sensor.range import RangeSensor
from uvnpy.toolkit.ros import PositionAndRange
from uvnpy.network.neighborhood import Neighborhood

class Point(UnmannedVehicle):
    def __init__(self, id, cnfg_file='../config/point.yaml', motion_kw={}, sensor_kw={}):
        super(Point, self).__init__(id, type='Point')
        # read config file
        config = yaml.load(open(cnfg_file))
        # motion model
        freq = motion_kw.get('freq', 1)
        sigma = config.get('sigma')
        config.update(sigma=np.multiply(freq**0.5, sigma))
        motion_kw.update(config)
        self.motion = VelocityModel(**motion_kw)
        # sensors
        self.range = RangeSensor()
        # filter
        xi = self.motion.x
        dxi = 0.1*self.range.sigma * np.array([1, 1, 0.1, 0.1])
        self.filter = Ekf(xi, dxi)

    def ctrl_step(self, u, t, landmarks=[]):
        self.filter.prediction(self.motion.f, u, t)
        p = self.p()
        if len(landmarks) > 0: 
            y = [self.range.measurement(p, l) for l in landmarks]
            self.filter.correction(self.h_range, y, landmarks)

    def p(self):
        return self.motion.x[:2].copy()

    def v(self):
        return self.motion.x[2:].copy()

    def hat_p(self):
        return self.filter.x[:2].copy()

    def hat_v(self):
        return self.filter.x[2:].copy()

    def cov_p(self):
        return self.filter.P[:2,:2].copy()

    def h_range(self, x, landmarks):
        #   Expected measurement
        p = x[:2]
        hat_y = [linalg.distance(p, l) for l in landmarks]
        #   Jacobian
        def Hi(p, l):
            j = np.subtract(p, l)/linalg.distance(p, l)
            return np.hstack([j, 0, 0])
        H = np.vstack([Hi(p,l) for l in landmarks])
        #   Noise
        R = np.diag([self.range.R.item() for _ in landmarks])
        return hat_y, H, R