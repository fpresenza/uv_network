=======================
Un paquete herramientas
=======================

El paquete contiene herramientas en desarrollo de redes reconfigurables
de vehiculos no tripulados.

Instalación
===========

Con lo siguiente se puede ejecutar `import uvnpy` desde cualquier
lado y funcionaría.

Ejecutar:

.. code-block:: bash

   python setup.py sdist bdist_wheel
   pip install ./dist/uvnets-0.0.1.tar.gz
